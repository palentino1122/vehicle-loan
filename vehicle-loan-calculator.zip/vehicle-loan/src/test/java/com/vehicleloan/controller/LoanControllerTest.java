package com.vehicleloan.controller;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.vehicleloan.model.Loan;

public class LoanControllerTest {
    private LoanController loanController;
    private Loan loan;

    @Before
    public void setUp() {
        loanController = new LoanController();
        loan = new Loan();
    }

    @Test
    public void testValidateLoan_NewVehicle_ValidDownPayment() {
        loan.setVehicleType("mobil");
        loan.setVehicleCondition("baru");
        loan.setVehicleYear(2024);
        loan.setTotalLoan(new BigDecimal("100000000")); // 100 juta
        loan.setLoanTenor(4);
        loan.setDownPayment(new BigDecimal("40000000")); // 40 juta (40% dari total pinjaman)
        assertTrue(loanController.validateAndCalculateLoan(loan));
    }

    @Test
    public void testValidateLoan_NewVehicle_InvalidDownPayment() {
        loan.setVehicleType("mobil");
        loan.setVehicleCondition("baru");
        loan.setVehicleYear(2024);
        loan.setTotalLoan(new BigDecimal("100000000")); // 100 juta
        loan.setLoanTenor(4);
        loan.setDownPayment(new BigDecimal("30000000")); // 30 juta (30% dari total pinjaman)
        assertFalse(loanController.validateAndCalculateLoan(loan));
    }

    @Test
    public void testValidateLoan_UsedVehicle_ValidDownPayment() {
        loan.setVehicleType("mobil");
        loan.setVehicleCondition("bekas");
        loan.setVehicleYear(2024);
        loan.setTotalLoan(new BigDecimal("100000000")); // 100 juta
        loan.setLoanTenor(4);
        loan.setDownPayment(new BigDecimal("30000000")); // 30 juta (30% dari total pinjaman)
        assertTrue(loanController.validateAndCalculateLoan(loan));
    }

    @Test
    public void testValidateLoan_UsedVehicle_InvalidDownPayment() {
        loan.setVehicleType("mobil");
        loan.setVehicleCondition("bekas");
        loan.setVehicleYear(2024);
        loan.setTotalLoan(new BigDecimal("100000000")); // 100 juta
        loan.setLoanTenor(4);
        loan.setDownPayment(new BigDecimal("20000000")); // 20 juta (20% dari total pinjaman)
        assertFalse(loanController.validateAndCalculateLoan(loan));
    }
}
