package com.vehicleloan;

import java.io.IOException;

import com.vehicleloan.controller.LoanController;
import com.vehicleloan.service.LoanService;
import com.vehicleloan.view.LoanView;

public class Main {

    public static void main(String[] args) throws IOException {
        LoanService loanService = new LoanService();
        LoanView loanView = new LoanView();
        LoanController loanController = new LoanController(loanService, loanView);

        if (args.length > 0) {
            loanController.processLoan(args[0]);
        } else {
            loanController.start();

        }
    }
}
