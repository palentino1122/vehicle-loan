package com.vehicleloan.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Scanner;

import com.vehicleloan.model.Loan;
import com.vehicleloan.service.LoanService;
import com.vehicleloan.view.LoanView;

public class LoanController {

    private LoanService loanService;
    private LoanView loanView;

    public LoanController(LoanService loanService, LoanView loanView) {
        this.loanService = loanService;
        this.loanView = loanView;
    }

    public LoanController() {
        this.loanService = new LoanService();
        this.loanView = new LoanView();
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            scanner = new Scanner(System.in);
            int choice = displayMenu(scanner);

            switch (choice) {
                case 1:
                    processLoan(scanner);
                    break;
                case 2:
                    loanService.loadExistingCalculation();
                    break;
                case 3:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    public int displayMenu(Scanner scanner) {
        System.out.println("Menu:");
        System.out.println("1. Calculate New Loan");
        System.out.println("2. Load Existing Calculation");
        System.out.println("3. Exit");
        System.out.print("Enter your choice: ");
        return Integer.parseInt(scanner.nextLine().trim());
    }

    public Loan readLoanFromFile(String filePath) {
        String vehicleType = "";
        String vehicleCondition = "";
        int vehicleYear = 0;
        BigDecimal totalLoan = BigDecimal.ZERO;
        int loanTenor = 0;
        BigDecimal downPayment = BigDecimal.ZERO;

        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(": ");
                if (parts.length < 2)
                    continue;

                switch (parts[0].toLowerCase()) {
                    case "jeniskendaraan":
                        vehicleType = parts[1].trim();
                        break;
                    case "kondisikendaraan":
                        vehicleCondition = parts[1].trim();
                        break;
                    case "tahunkendaraan":
                        vehicleYear = Integer.parseInt(parts[1].trim());
                        break;
                    case "jumlahpinjaman":
                        totalLoan = new BigDecimal(parts[1].trim());
                        break;
                    case "tenorpinjaman":
                        loanTenor = Integer.parseInt(parts[1].trim());
                        break;
                    case "jumlahdp":
                        downPayment = new BigDecimal(parts[1].trim());
                        break;
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return new Loan(vehicleType, vehicleCondition, vehicleYear, totalLoan, loanTenor, downPayment);
    }

    private Loan readLoanFromConsole(Scanner scanner) {
        Loan loan = new Loan();

        System.out.print("Enter vehicle type (Mobil/Motor): ");
        loan.setVehicleType(scanner.nextLine().trim());

        System.out.print("Enter condition (Baru/Bekas): ");
        loan.setVehicleCondition(scanner.nextLine().trim());

        System.out.print("Enter vehicle year: ");
        loan.setVehicleYear(scanner.nextInt());

        System.out.print("Enter total loan amount: ");
        String decimalInput = scanner.next().trim();
        BigDecimal checkBalSign = new BigDecimal(decimalInput);
        loan.setTotalLoan(checkBalSign);

        System.out.print("Enter loan tenor (in years): ");
        loan.setLoanTenor(scanner.nextInt());

        System.out.print("Enter down payment amount: ");
        String decimal = scanner.next().trim();
        BigDecimal checkDe = new BigDecimal(decimal);
        loan.setDownPayment(checkDe);

        return loan;
    }

    public boolean validateAndCalculateLoan(Loan loan) {
        if (loanService.validateLoan(loan)) {
            loanView.displayInstallments(loanService.calculateMonthlyInstallments(loan));
            return true;
        } else {
            return false;
        }
    }

    public void processLoan(String filePath) {
        Loan loan = readLoanFromFile(filePath);
        loanView.displayInstallments(loanService.calculateMonthlyInstallments(loan));
    }

    // public void processLoan() {
    // Loan loan = readLoanFromConsole();
    // loanView.displayInstallments(loanService.calculateMonthlyInstallments(loan));
    // }
    public void processLoan(Scanner scanner) {
        Loan loan = readLoanFromConsole(scanner);
        validateAndCalculateLoan(loan);
    }
}
