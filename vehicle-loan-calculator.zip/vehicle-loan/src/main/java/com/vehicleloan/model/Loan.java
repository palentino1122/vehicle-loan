package com.vehicleloan.model;

import java.math.BigDecimal;

public class Loan {
    private String vehicleType;
    private String vehicleCondition;
    private int vehicleYear;
    private BigDecimal totalLoan;
    private int loanTenor;
    private BigDecimal downPayment;
    private BigDecimal monthlyInstallment;
    private BigDecimal interestRate;

    public Loan(String vehicleType, String vehicleCondition, int vehicleYear, BigDecimal totalLoan, int loanTenor,
            BigDecimal downPayment) {
        this.vehicleType = vehicleType;
        this.vehicleCondition = vehicleCondition;
        this.vehicleYear = vehicleYear;
        this.totalLoan = totalLoan;
        this.loanTenor = loanTenor;
        this.downPayment = downPayment;
    }

    public Loan() {
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleCondition() {
        return vehicleCondition;
    }

    public void setVehicleCondition(String vehicleCondition) {
        this.vehicleCondition = vehicleCondition;
    }

    public int getVehicleYear() {
        return vehicleYear;
    }

    public void setVehicleYear(int vehicleYear) {
        this.vehicleYear = vehicleYear;
    }

    public BigDecimal getTotalLoan() {
        return totalLoan;
    }

    public void setTotalLoan(BigDecimal totalLoan) {
        this.totalLoan = totalLoan;
    }

    public int getLoanTenor() {
        return loanTenor;
    }

    public void setLoanTenor(int loanTenor) {
        this.loanTenor = loanTenor;
    }

    public BigDecimal getDownPayment() {
        return downPayment;
    }

    public void setDownPayment(BigDecimal downPayment) {
        this.downPayment = downPayment;
    }

    public BigDecimal getMonthlyInstallment() {
        return monthlyInstallment;
    }

    public void setMonthlyInstallment(BigDecimal monthlyInstallment) {
        this.monthlyInstallment = monthlyInstallment;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

}
