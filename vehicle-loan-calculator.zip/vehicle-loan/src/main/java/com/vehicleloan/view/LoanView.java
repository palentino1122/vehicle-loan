package com.vehicleloan.view;

import java.util.List;

public class LoanView {

    public void displayInstallments(List<String> installments) {
        for (String installment : installments) {
            System.out.println(installment);
        }
    }
}