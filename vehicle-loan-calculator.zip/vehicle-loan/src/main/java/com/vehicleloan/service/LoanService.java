package com.vehicleloan.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

import com.vehicleloan.model.Loan;

public class LoanService {

    public boolean validateLoan(Loan loan) {
        int currentYear = java.time.Year.now().getValue();

        // Validate vehicle type (Mobil/Motor)
        if (!loan.getVehicleType().equalsIgnoreCase("mobil") && !loan.getVehicleType().equalsIgnoreCase("motor")) {
            System.out.println("Invalid vehicle type. Please enter 'Mobil' or 'Motor'.");
            return false;
        }

        // Validate condition (Baru/Bekas)
        if (!loan.getVehicleCondition().equalsIgnoreCase("baru")
                && !loan.getVehicleCondition().equalsIgnoreCase("bekas")) {
            System.out.println("Invalid condition. Please enter 'Baru' or 'Bekas'.");
            return false;
        }

        if (loan.getVehicleCondition().equalsIgnoreCase("baru") && loan.getVehicleYear() < currentYear - 1) {
            System.out.println("Vehicle must be newer than 1 year for new vehicle.");
            return false;
        }
        // Validasi untuk memastikan vehicleYear hanya numerik dan 4 digit
        String vehicleYearStr = String.valueOf(loan.getVehicleYear());
        if (!vehicleYearStr.matches("\\d{4}")) {
            System.out.println("Vehicle year must be numeric and 4 digits long.");
            return false;
        }
        // Validate total loan amount (<= 1 miliar)
        BigDecimal oneBillion = new BigDecimal("1000000000");
        if (loan.getTotalLoan().compareTo(oneBillion) > 0) {
            System.out.println("Invalid total loan amount. Amount must be less than or equal to 1 miliar.");
            return false;
        }

        if (loan.getLoanTenor() < 1 || loan.getLoanTenor() > 6) {
            System.out.println("Loan tenor must be between 1 and 6 years.");
            return false;
        }

        // Validate down payment percentage for new vehicles
        BigDecimal downPaymentPercentage = loan.getDownPayment().divide(loan.getTotalLoan(), 2,
                BigDecimal.ROUND_HALF_UP);
        BigDecimal minimumDownPaymentNew = new BigDecimal("0.35");
        if (loan.getVehicleCondition().equalsIgnoreCase("baru")
                && downPaymentPercentage.compareTo(minimumDownPaymentNew) < 0) {
            System.out.println(
                    "Invalid down payment for new vehicle. Down payment must be at least 35% of the total loan.");
            return false;
        }

        // Validate down payment percentage for used vehicles
        BigDecimal minimumDownPaymentUsed = new BigDecimal("0.25");
        if (loan.getVehicleCondition().equalsIgnoreCase("bekas")
                && downPaymentPercentage.compareTo(minimumDownPaymentUsed) < 0) {
            System.out.println(
                    "Invalid down payment for used vehicle. Down payment must be at least 25% of the total loan.");
            return false;
        }

        return true;
    }

    public List<String> calculateMonthlyInstallments(Loan loan) {
        double baseRate = loan.getVehicleType().equalsIgnoreCase("mobil") ? 8.0 : 9.0;
        List<String> installments = new ArrayList<>();
        BigDecimal loanAmount = loan.getTotalLoan().subtract(loan.getDownPayment());

        double yearRate = baseRate;
        for (int year = 1; year <= loan.getLoanTenor(); year++) {

            if (year > 1) {
                if (year % 2 == 0) {
                    yearRate += 0.1;
                } else {
                    yearRate += 0.5;
                }
            }

            double monthlyRate = yearRate / 100 / 12;
            BigDecimal monthlyInstallment = loanAmount.multiply(BigDecimal.valueOf(monthlyRate)).divide(
                    BigDecimal.ONE.subtract(BigDecimal.valueOf(Math.pow(1 + monthlyRate, -loan.getLoanTenor() * 12))),
                    BigDecimal.ROUND_HALF_UP);
            installments.add(
                    String.format("Tahun %d: Rp. %,.2f/bln, Suku Bunga: %.1f%%", year, monthlyInstallment, yearRate));
        }

        return installments;
    }

    public Loan loadExistingCalculation() {
        try {
            URL url = new URL("https://run.mocky.io/v3/4b76309f-a963-4501-a7c4-0e563d126172");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }
            in.close();
            conn.disconnect();

            JSONObject json = new JSONObject(content.toString());
            return new Loan(
                    json.getString("vehicleType"),
                    json.getString("vehicleCondition"),
                    json.getInt("vehicleYear"),
                    json.getBigDecimal("totalLoan"),
                    json.getInt("loanTenor"),
                    json.getBigDecimal("downPayment"));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
